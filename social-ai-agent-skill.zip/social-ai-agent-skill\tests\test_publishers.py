#!/usr/bin/env python3
"""
Tests for the Social AI Agent publisher tools.
Run with: pytest tests/test_publishers.py -v
"""

import json
import os
import sys
import pytest
from unittest.mock import MagicMock, patch, PropertyMock
from datetime import datetime

# Add tools to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))


# ─── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_post():
    from publisher import Post
    return Post(
        post_id="test-123",
        platform="instagram",
        post_type="post",
        caption="Test caption for unit testing 🚀",
        hashtags=["#test", "#unittest", "#python"],
        media_urls=["https://example.com/image.jpg"],
    )


@pytest.fixture
def mock_publisher():
    """Publisher with mocked API connections."""
    with patch("publisher.SocialAPIConnector") as mock_connector:
        mock_connector.return_value.credentials = {
            "meta": {
                "access_token": "test_token",
                "page_id": "test_page",
                "ig_account_id": "test_ig",
            },
            "x": {
                "api_key": "key", "api_secret": "secret",
                "access_token": "token", "access_secret": "secret",
                "bearer_token": "bearer",
            },
            "tiktok": {"client_key": "k", "client_secret": "s", "access_token": "t"},
            "linkedin": {
                "access_token": "t", "client_id": "id",
                "client_secret": "s", "person_urn": "urn",
            },
            "youtube": {"api_key": "k", "channel_id": "ch", "oauth_credentials": "{}"},
        }
        mock_connector.return_value.validate_credentials.return_value = True
        from publisher import MultiPlatformPublisher
        publisher = MultiPlatformPublisher()
        publisher.connector = mock_connector.return_value
        yield publisher


# ─── Post Tests ──────────────────────────────────────────────────────────────

class TestPost:
    def test_full_caption_combines_text_and_hashtags(self):
        from publisher import Post
        post = Post(
            post_id="1",
            platform="instagram",
            post_type="post",
            caption="Hello world",
            hashtags=["#hello", "#world"],
        )
        assert "#hello" in post.full_caption
        assert "#world" in post.full_caption
        assert "Hello world" in post.full_caption

    def test_full_caption_with_no_hashtags(self):
        from publisher import Post
        post = Post(
            post_id="1",
            platform="x",
            post_type="post",
            caption="Simple tweet",
            hashtags=[],
        )
        assert post.full_caption == "Simple tweet"

    def test_post_creation_with_defaults(self):
        from publisher import Post
        post = Post(post_id="1", platform="linkedin", post_type="post", caption="Test")
        assert post.hashtags == []
        assert post.media_urls == []
        assert post.metadata == {}
        assert post.scheduled_time is None


# ─── Publisher Tests ──────────────────────────────────────────────────────────

class TestMultiPlatformPublisher:
    def test_min_gap_tiktok(self, mock_publisher):
        assert mock_publisher._min_gap("tiktok") == 300

    def test_min_gap_instagram(self, mock_publisher):
        assert mock_publisher._min_gap("instagram") == 120

    def test_min_gap_x(self, mock_publisher):
        assert mock_publisher._min_gap("x") == 60

    def test_min_gap_unknown_platform(self, mock_publisher):
        assert mock_publisher._min_gap("unknown") == 60

    def test_get_summary_empty(self, mock_publisher):
        summary = mock_publisher.get_summary()
        assert summary["total_attempted"] == 0
        assert summary["successful"] == 0
        assert summary["failed"] == 0
        assert summary["results"] == []

    def test_dispatch_raises_for_unknown_platform(self, mock_publisher, sample_post):
        from publisher import Post
        bad_post = Post(
            post_id="bad", platform="myspace", post_type="post", caption="Test"
        )
        with pytest.raises(ValueError, match="Unsupported platform"):
            mock_publisher._dispatch(bad_post)

    def test_publish_records_result(self, mock_publisher, sample_post):
        from publisher import PublishResult
        mock_publisher._dispatch = MagicMock(
            return_value=PublishResult(
                post_id=sample_post.post_id,
                platform="instagram",
                success=True,
                platform_post_id="ig123",
                post_url="https://instagram.com/p/ig123",
                published_at=datetime.utcnow().isoformat(),
            )
        )
        result = mock_publisher.publish(sample_post)
        assert result.success is True
        assert len(mock_publisher.results) == 1

    def test_publish_all_returns_all_results(self, mock_publisher):
        from publisher import Post, PublishResult
        posts = [
            Post(post_id=f"{i}", platform="x", post_type="post", caption=f"Tweet {i}")
            for i in range(3)
        ]
        mock_publisher._dispatch = MagicMock(
            side_effect=[
                PublishResult(post_id=str(i), platform="x", success=True)
                for i in range(3)
            ]
        )
        results = mock_publisher.publish_all(posts)
        assert len(results) == 3
        assert all(r.success for r in results)


# ─── API Connector Tests ──────────────────────────────────────────────────────

class TestAPIConnector:
    def test_load_credentials_from_env(self, monkeypatch):
        monkeypatch.setenv("META_APP_ID", "test_app_123")
        monkeypatch.setenv("META_ACCESS_TOKEN", "test_token")
        monkeypatch.setenv("META_PAGE_ID", "page_123")
        monkeypatch.setenv("META_IG_ACCOUNT_ID", "ig_123")
        monkeypatch.setenv("META_APP_SECRET", "secret")

        from api_connector import SocialAPIConnector
        connector = SocialAPIConnector()
        assert connector.credentials["meta"]["app_id"] == "test_app_123"
        assert connector.credentials["meta"]["access_token"] == "test_token"

    def test_validate_credentials_missing(self, monkeypatch):
        monkeypatch.setenv("META_APP_ID", "")
        from api_connector import SocialAPIConnector
        connector = SocialAPIConnector()
        # With empty credentials, validation should fail
        result = connector.validate_credentials("meta")
        assert result is False

    def test_get_client_unsupported_platform(self):
        from api_connector import SocialAPIConnector
        connector = SocialAPIConnector()
        with pytest.raises(ValueError):
            connector.get_client("myspace")


# ─── Integration Tests (skipped in CI without real credentials) ───────────────

@pytest.mark.integration
@pytest.mark.skipif(not os.getenv("META_ACCESS_TOKEN"), reason="No Meta credentials")
class TestMetaIntegration:
    def test_meta_connection(self):
        from api_connector import SocialAPIConnector
        connector = SocialAPIConnector()
        result = connector.test_connection("meta")
        assert result["connected"] is True


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
