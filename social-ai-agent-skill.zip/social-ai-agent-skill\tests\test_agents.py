#!/usr/bin/env python3
"""
Tests for AI content generation agents.
Run with: pytest tests/test_agents.py -v
"""

import json
import os
import sys
import pytest
from unittest.mock import MagicMock, patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))


# ─── Content Generator Tests ──────────────────────────────────────────────────

class TestAIContentGenerator:
    def test_detect_provider_anthropic(self, monkeypatch):
        monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-ant-test")
        monkeypatch.delenv("OPENAI_API_KEY", raising=False)
        monkeypatch.delenv("GOOGLE_API_KEY", raising=False)

        with patch("content_generator.AIContentGenerator._init_client") as mock_init:
            mock_init.return_value = MagicMock()
            from content_generator import AIContentGenerator
            gen = AIContentGenerator(provider="auto")
            # Provider should be detected as claude since ANTHROPIC_API_KEY is set
            # (actual detection depends on env order)

    def test_parse_json_response_valid(self):
        with patch("content_generator.AIContentGenerator._init_client"):
            from content_generator import AIContentGenerator
            gen = AIContentGenerator.__new__(AIContentGenerator)
            gen.provider = "openai"
            
            valid_json = '{"content_package": {"topic": "test", "posts": []}}'
            result = gen._parse_json_response(valid_json)
            assert result == {"content_package": {"topic": "test", "posts": []}}

    def test_parse_json_response_with_code_block(self):
        with patch("content_generator.AIContentGenerator._init_client"):
            from content_generator import AIContentGenerator
            gen = AIContentGenerator.__new__(AIContentGenerator)
            gen.provider = "openai"
            
            markdown_json = '```json\n{"key": "value"}\n```'
            result = gen._parse_json_response(markdown_json)
            assert result == {"key": "value"}

    def test_parse_json_response_invalid_returns_raw(self):
        with patch("content_generator.AIContentGenerator._init_client"):
            from content_generator import AIContentGenerator
            gen = AIContentGenerator.__new__(AIContentGenerator)
            gen.provider = "openai"
            
            invalid_json = "This is not JSON"
            result = gen._parse_json_response(invalid_json)
            assert "raw_response" in result
            assert result["parse_error"] is True


# ─── ContentRequest Tests ─────────────────────────────────────────────────────

class TestContentRequest:
    def test_default_values(self):
        from content_generator import ContentRequest
        req = ContentRequest(topic="test", platforms=["instagram"])
        assert req.brand_voice == "casual and engaging"
        assert req.num_posts == 5
        assert req.include_reels is True
        assert req.include_hashtags is True
        assert req.language == "English"
        assert req.content_pillars is None

    def test_custom_values(self):
        from content_generator import ContentRequest
        req = ContentRequest(
            topic="fitness",
            platforms=["instagram", "tiktok"],
            brand_voice="motivational",
            niche="health and wellness",
            num_posts=10,
        )
        assert req.topic == "fitness"
        assert len(req.platforms) == 2
        assert req.num_posts == 10
        assert req.niche == "health and wellness"


# ─── Mock Generation Tests ────────────────────────────────────────────────────

class TestMockGeneration:
    @pytest.fixture
    def mock_generator(self):
        with patch("content_generator.AIContentGenerator._init_client") as mock:
            mock.return_value = MagicMock()
            from content_generator import AIContentGenerator, ContentRequest
            gen = AIContentGenerator.__new__(AIContentGenerator)
            gen.provider = "openai"
            gen.client = MagicMock()
            gen.SYSTEM_PROMPT = "Test system prompt"
            return gen

    def test_generate_post_package_calls_generate(self, mock_generator):
        from content_generator import ContentRequest
        expected_output = json.dumps({
            "content_package": {
                "topic": "test",
                "posts": [
                    {
                        "platform": "instagram",
                        "type": "post",
                        "hook": "Test hook",
                        "body": "Test body",
                        "cta": "Test CTA",
                        "full_caption": "Test hook\n\nTest body\n\nTest CTA",
                        "hashtags": ["#test"],
                        "tagline": "Test tagline",
                        "image_prompt": "Test prompt",
                        "reel_script": None,
                        "b_roll_notes": None,
                        "audio_suggestion": None,
                    }
                ],
            }
        })
        mock_generator.generate = MagicMock(return_value=expected_output)

        req = ContentRequest(topic="test topic", platforms=["instagram"])
        result = mock_generator.generate_post_package(req)

        assert "content_package" in result
        assert result["content_package"]["topic"] == "test"
        assert len(result["content_package"]["posts"]) == 1
        mock_generator.generate.assert_called_once()

    def test_generate_reel_script_returns_dict(self, mock_generator):
        expected = json.dumps({
            "script": {"hook": "Hook text", "duration": 60, "sections": []}
        })
        mock_generator.generate = MagicMock(return_value=expected)

        result = mock_generator.generate_reel_script("productivity tips", 60)
        assert isinstance(result, dict)
        mock_generator.generate.assert_called_once()


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])
