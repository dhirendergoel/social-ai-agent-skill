# Viral Content Formulas

## The 10 Proven Viral Content Frameworks

---

### 1. The Listicle
**Formula**: `[Number] [Adjective] [Topic] That [Promise]`

**Structure**:
```
Hook: [Number] things about [TOPIC] that changed my life:

1. [Point] — [Brief explanation]
2. [Point] — [Brief explanation]
3. [Point] — [Brief explanation]
...

Which one hit hardest? 👇
```

**Why it works**: Numbers set clear expectations, creates anticipation, easy to consume.

**Best for**: Instagram carousels, LinkedIn, X threads, TikTok

---

### 2. The Before/After Transformation
**Formula**: `[Pain State] → [Dream State] in [Timeframe]`

**Structure**:
```
6 months ago: [RELATABLE STRUGGLE]
Today: [IMPRESSIVE RESULT]

What changed? [3-5 specific actions]

Here's the exact playbook 🧵
```

**Why it works**: Shows proof of concept, creates aspiration, deeply relatable.

**Best for**: All platforms, especially Instagram and LinkedIn

---

### 3. The Myth Buster
**Formula**: `[Common Belief] is WRONG. Here's the truth:`

**Structure**:
```
Everyone says [COMMON ADVICE].
They're wrong.

Here's what actually works (backed by data):

[CONTRARIAN TRUTH WITH PROOF]

RT to save someone from bad advice 🔁
```

**Why it works**: Triggers curiosity, positions as expert, shareable.

---

### 4. The POV (Point of View) Story
**Formula**: `POV: You [relatable scenario]`

**Structure (Reel/TikTok)**:
```
POV: [RELATABLE SCENARIO]

[Scene plays out showing transformation/revelation]

[Surprising ending or punchline]

[CTA]
```

**Why it works**: Immersive, creates empathy, algorithm loves it on TikTok/Reels.

---

### 5. The Day in My Life
**Formula**: Shows authentic behind-the-scenes lifestyle content

**Structure**:
```
Hook: "A day in my life as [ROLE] 🎥"
- Morning routine / first action of day
- Core work activity #1
- Lunch/break moment (humanizing)
- Core work activity #2
- Evening wind-down or result
- Closing reflection or lesson
```

**Why it works**: Builds parasocial relationship, highly rewatchable, broad appeal.

---

### 6. The Controversial Opinion
**Formula**: `Unpopular opinion: [CONTRARIAN TAKE ON POPULAR TOPIC]`

**Structure**:
```
Unpopular opinion:

[SURPRISING CLAIM THAT CHALLENGES CONVENTIONAL WISDOM]

Here's why I believe this:

[3 supporting points]

Agree or disagree? Let me know below 👇
```

**Why it works**: Triggers comment debate (algorithm loves it), positions as thought leader.

**Warning**: Stay away from politics, religion, personal attacks.

---

### 7. The Curiosity Gap
**Formula**: `[Partial info] that [audience] never talks about`

**Structure**:
```
The [TOPIC] secret that nobody in [INDUSTRY] will tell you:

[Dramatic pause / visual cut]

[REVEAL]

Save this — you'll need it.
```

**Why it works**: Exploits brain's pattern-completion drive, drives watch time.

---

### 8. The How-To Tutorial
**Formula**: `How to [achieve specific result] in [steps/timeframe]`

**Structure**:
```
How to [RESULT] in [TIMEFRAME]:

Step 1: [ACTION]
Step 2: [ACTION]
Step 3: [ACTION]

[PRO TIP at the end]

Save this for later 🔖
```

**Why it works**: Provides immediate value, high save rate, positions as authority.

---

### 9. The Reactivity / News Jacking
**Formula**: React to trending news/events with your niche angle

**Structure**:
```
[TRENDING NEWS/EVENT] just happened.

Here's what this means for [YOUR AUDIENCE]:

[YOUR UNIQUE ANALYSIS]

[WHAT THEY SHOULD DO NOW]
```

**Why it works**: Timeliness boost in algorithm, relevant hashtag opportunity, positions as current.

---

### 10. The Challenge / Interactive
**Formula**: Create shareable challenge with your brand

**Structure**:
```
[BRANDED CHALLENGE NAME] 🔥

Rules:
1. [SIMPLE ACTION]
2. [TAG OTHERS]
3. [USE HASHTAG]

I'll feature my favorites!

Tag 2 friends who would do this 👇
#[BRANDCHALLENGE]
```

**Why it works**: Viral loop built in, UGC generator, community building.

---

## Engagement Multipliers

Add any of these to any post to boost engagement:

| Multiplier | Implementation | Effect |
|-----------|---------------|--------|
| Relatability | "Tell me I'm not alone..." | Comments |
| Urgency | "Limited time / Only today" | Shares |
| Social proof | "10,000 people already..." | Trust |
| Mystery | "The answer will surprise you" | Watch time |
| Controversy | "Hot take incoming..." | Debate |
| Community | "Everyone in [GROUP] needs this" | Shares |
| FOMO | "If you miss this, you'll regret it" | Saves |
| Authority | "After 10 years of research..." | Credibility |

---

## Content Length Optimization

| Format | Optimal Length | Why |
|--------|---------------|-----|
| Instagram caption | 125–300 chars visible | Hook before "more" |
| Instagram reel | 15–30 seconds | Completion rate |
| X tweet | 71–100 chars | No link truncation |
| TikTok | 21–34 seconds OR 2-3 minutes | Algorithm valleys |
| LinkedIn | 1,300–1,500 chars | Professional depth |
| YouTube Short | 15–60 seconds | Suggested ratio |
| Facebook | 50–80 chars (images) | Mobile preview |
