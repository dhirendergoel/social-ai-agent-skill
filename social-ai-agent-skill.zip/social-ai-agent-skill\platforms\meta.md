# Meta (Facebook & Instagram & Threads) Platform Guide

## Overview
Meta's family of apps covers Facebook, Instagram, and Threads — each with distinct culture, algorithm, and audience behavior.

---

## Facebook

### Algorithm Signals (Priority Order)
1. **Meaningful interactions** — comments and shares > likes
2. **Watch time** — video completion rate
3. **Shares** — the highest-value action on Facebook
4. **Comment depth** — replies to comments = algorithm boost
5. **Reactions** — Love/Wow > Like

### Content Types & Specs

| Type | Specs | Best For |
|------|-------|---------|
| Text Post | Max 63,206 chars (500 optimal) | Personal stories, opinions |
| Photo | 1200×630px, JPG/PNG | Product, lifestyle |
| Video | MP4, max 10GB, up to 240 min | Tutorials, stories |
| Reel | 9:16, MP4, 90 sec max | Entertainment, reach |
| Carousel | Up to 10 images/videos | Product showcase |
| Story | 9:16, 24hr disappearing | Daily updates |
| Live | Real-time, up to 8 hours | Events, Q&A |

### Facebook API Endpoints
```
Page Feed Post:     POST /v19.0/{page-id}/feed
Page Photo:         POST /v19.0/{page-id}/photos
Page Video:         POST /v19.0/{page-id}/videos
Page Reel:          POST /v19.0/{page-id}/videos (content_category: REELS)
Scheduled Post:     Add scheduled_publish_time (unix timestamp) + published: false
```

### Facebook Content Best Practices
- **Go live weekly** — Facebook heavily promotes Live videos
- **Ask questions** — drives comments which boost reach
- **Use Facebook Groups** — higher organic reach than Pages
- **Tag people/pages** — increases distribution
- **Post native video** — not YouTube links
- **Facebook Reels** — platform actively pushing, great organic reach in 2024-25

---

## Instagram

### Algorithm Signals (Priority Order)
1. **Saves** — the #1 signal for Instagram in 2024-25
2. **Shares** — especially Story shares of posts
3. **Comments** — quality over quantity
4. **Watch time** — for Reels (completion rate key)
5. **Likes** — still counts but less weight

### Content Types & Specs

| Type | Ratio | Resolution | Duration | Caption |
|------|-------|-----------|----------|---------|
| Feed (Square) | 1:1 | 1080×1080 | — | 2,200 chars |
| Feed (Portrait) | 4:5 | 1080×1350 | — | 2,200 chars |
| Feed (Landscape) | 1.91:1 | 1080×566 | — | 2,200 chars |
| Reels | 9:16 | 1080×1920 | 15–90s (up to 3min) | 2,200 chars |
| Stories | 9:16 | 1080×1920 | 15s photo / 60s video | 125 chars |
| Carousel | 1:1 or 4:5 | 1080×1080 | Up to 10 slides | 2,200 chars |
| Guides | — | — | — | — |

### Instagram Graph API — Key Calls
```python
# Step 1: Create container
POST /{ig-user-id}/media
  image_url: "https://..."
  caption: "Post text #hashtags"
  media_type: IMAGE | VIDEO | REELS | CAROUSEL_ALBUM

# Step 2: Publish
POST /{ig-user-id}/media_publish
  creation_id: {id from step 1}

# Get insights
GET /{media-id}/insights
  metric: impressions,reach,saved,shares,comments,likes
```

### Instagram Hashtag Strategy
- **Feed posts**: 8–15 hashtags (placed in caption or first comment)
- **Reels**: 3–8 hashtags (in caption)
- **Stories**: 1–3 hashtags (use sticker, not text overlay)
- **Mix**: 20% mega + 50% mid-tier + 30% niche

### Instagram Best Practices
- **Reels get 3x more reach** than static posts — prioritize them
- **Post Reels to Feed** to get double exposure
- **Carousel posts** have highest save rate (great for educational content)
- **Use alt text** for accessibility AND SEO
- **Stories daily** — keep you top of feed
- **Collab posts** — partner with creators for 2x reach
- **Hook text overlay** in first 1-3 seconds of Reels (critical)

---

## Threads

### Platform Notes
- Launched by Meta in 2023
- Text-first, Twitter-like
- Growing rapidly (200M+ users)
- Cross-posts to Instagram Stories available
- No ads yet — high organic reach window

### Specs
- Posts: 500 characters
- Photos: Up to 10 per post
- Video: Up to 5 minutes
- Links: 1 per post (shown as preview card)

### Threads API
```python
# Requires Instagram Graph API access
POST /{ig-user-id}/threads
  text: "Post content"
  media_type: TEXT | IMAGE | VIDEO | CAROUSEL

POST /{ig-user-id}/threads_publish
  creation_id: {id from above}
```

### Threads Strategy
- More conversational, raw, unpolished tone works best
- Reply to others to build community (algorithm rewards engagement)
- Repurpose X threads here with slight modifications
- Opinion and hot-take posts perform well

---

## Meta Business Suite Integration
- Manage Facebook + Instagram from one dashboard
- Schedule posts up to 3 months in advance
- Native analytics across both platforms
- Ad campaign management (Boost posts)
- Inbox management (all DMs in one place)

**API for Business Suite Scheduling:**
```python
POST /{page-id}/feed
  message: "content"
  scheduled_publish_time: 1700000000  # Unix timestamp
  published: false
```
