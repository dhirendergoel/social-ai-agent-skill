# Complete Setup Guide

## Prerequisites

Before starting, ensure you have:
- Python 3.9+ installed
- pip or uv package manager
- Git installed
- API developer accounts (see below)
- An AI API key (at least one of: Anthropic, OpenAI, Google, xAI)

---

## Step 1: Clone & Install

```bash
git clone https://github.com/YOUR_USERNAME/social-ai-agent-skill.git
cd social-ai-agent-skill

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

---

## Step 2: Configure Environment Variables

Create a `.env` file in the project root:

```bash
cp .env.example .env
```

Edit `.env` with your credentials:

```env
# AI Provider (at least one required)
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
GOOGLE_API_KEY=AIza...
XAI_API_KEY=xai-...

# Meta (Facebook + Instagram)
META_APP_ID=your_app_id
META_APP_SECRET=your_app_secret
META_ACCESS_TOKEN=your_long_lived_token
META_PAGE_ID=your_facebook_page_id
META_IG_ACCOUNT_ID=your_instagram_account_id

# X (Twitter)
X_API_KEY=your_api_key
X_API_SECRET=your_api_secret
X_ACCESS_TOKEN=your_access_token
X_ACCESS_SECRET=your_access_secret
X_BEARER_TOKEN=your_bearer_token

# TikTok
TIKTOK_CLIENT_KEY=your_client_key
TIKTOK_CLIENT_SECRET=your_client_secret
TIKTOK_ACCESS_TOKEN=your_access_token

# LinkedIn
LINKEDIN_CLIENT_ID=your_client_id
LINKEDIN_CLIENT_SECRET=your_client_secret
LINKEDIN_ACCESS_TOKEN=your_access_token
LINKEDIN_PERSON_URN=your_person_urn

# YouTube (optional)
YOUTUBE_API_KEY=your_api_key
YOUTUBE_CHANNEL_ID=your_channel_id
```

---

## Step 3: Set Up API Access

### Meta (Facebook + Instagram)
1. Go to [developers.facebook.com](https://developers.facebook.com)
2. Create a new app → "Business" type
3. Add products: **Instagram Graph API**, **Pages API**
4. Under "Permissions", request:
   - `pages_manage_posts`
   - `instagram_basic`
   - `instagram_content_publish`
5. Generate a **Page Access Token** (long-lived)
6. Get your **Page ID** from your Facebook Page settings
7. Get your **Instagram Account ID** via Graph API Explorer:
   ```
   GET /me/accounts → find page → GET /{page-id}?fields=instagram_business_account
   ```

### X (Twitter)
1. Apply at [developer.twitter.com](https://developer.twitter.com)
2. Create a project and app
3. Under "User authentication settings":
   - App permissions: **Read and Write**
   - App type: Web App
4. Generate all 4 keys: API Key, API Secret, Access Token, Access Secret
5. Enable OAuth 1.0a and OAuth 2.0

### TikTok
1. Register at [developers.tiktok.com](https://developers.tiktok.com)
2. Create an app → enable **Content Posting API**
3. Submit for review (takes 1–5 business days)
4. After approval, generate Client Key & Secret
5. Complete OAuth flow to get Access Token

### LinkedIn
1. Go to [linkedin.com/developers](https://www.linkedin.com/developers)
2. Create an app and associate with a company page
3. Request these products:
   - **Share on LinkedIn**
   - **Sign In with LinkedIn using OpenID Connect**
4. Add OAuth 2.0 redirect URL
5. Generate access token with these scopes:
   - `w_member_social` (post on behalf of user)
   - `r_liteprofile`

### YouTube
1. Go to [console.cloud.google.com](https://console.cloud.google.com)
2. Enable **YouTube Data API v3**
3. Create OAuth 2.0 credentials
4. Download credentials JSON → set as `YOUTUBE_OAUTH_CREDENTIALS`

---

## Step 4: Configure Brand Voice

Edit `configs/content_rules.yaml`:
```yaml
brand:
  name: "Your Brand"
  tagline: "Your tagline"
  
voice:
  tone: "casual"  # or professional/humorous/inspirational
  
audience:
  primary:
    age_range: "25-45"
    demographics: "your target audience description"
```

---

## Step 5: Test Connections

```bash
# Test all API connections
python tools/api_connector.py

# Expected output:
# ✅ META: Connected
# ✅ X: Connected
# ✅ TIKTOK: Connected
# ✅ LINKEDIN: Connected
# ⚠️ YOUTUBE: Missing credentials (optional)
```

---

## Step 6: Generate Your First Content

```bash
# Generate content for a topic
python tools/content_generator.py \
  --topic "productivity tips for entrepreneurs" \
  --platforms instagram x tiktok linkedin \
  --voice "casual and energetic" \
  --posts 5 \
  --output content_output.json
```

---

## Step 7: Review & Publish

```bash
# Review the generated content
cat content_output.json

# Publish (after reviewing)
python tools/publisher.py --input content_output.json

# Publish to specific platform only
python tools/publisher.py --input content_output.json --platform instagram
```

---

## Step 8: Load as AI Skill

### In Claude:
1. Add `SKILL.md` contents to your system prompt, or
2. Place `SKILL.md` as `CLAUDE.md` in your project root

### In Gemini / Antigravity:
1. Copy the entire `social-ai-agent-skill/` folder to your skills directory
2. The skill will be auto-discovered

### In ChatGPT:
1. Go to Settings → Custom Instructions
2. Paste the contents of `SKILL.md` in the "What would you like ChatGPT to know" section

### In Grok:
1. Use the xAI API
2. Pass `SKILL.md` contents as the system message

---

## Troubleshooting

| Error | Solution |
|-------|---------|
| `Missing credentials` | Check `.env` file and environment variables |
| `Rate limit exceeded` | Wait 15 minutes, then retry |
| `Invalid token` | Regenerate access token from platform developer console |
| `Permission denied` | Check API scopes/permissions for your app |
| `No AI provider` | Set at least one AI API key in `.env` |

---

## Support

- Open an issue on GitHub
- Read platform-specific guides in `platforms/`
- Check API credentials guide: `docs/api_credentials.md`
