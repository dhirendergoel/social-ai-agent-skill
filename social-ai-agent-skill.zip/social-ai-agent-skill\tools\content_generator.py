#!/usr/bin/env python3
"""
Social AI Agent Skill — AI Content Generation Pipeline
Generates viral social media content using multiple AI providers.
Supports: OpenAI, Anthropic (Claude), Google (Gemini), Grok (xAI), Ollama (local)
"""

import os
import json
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class ContentRequest:
    topic: str
    platforms: List[str]
    brand_voice: str = "casual and engaging"
    niche: str = ""
    audience: str = "general"
    content_pillars: List[str] = None
    num_posts: int = 5
    include_reels: bool = True
    include_hashtags: bool = True
    language: str = "English"


class AIContentGenerator:
    """
    Universal content generator that works with any AI provider.
    Automatically selects available AI backend.
    """

    SYSTEM_PROMPT = """You are a world-class social media content strategist and copywriter.
    You create viral, platform-native content that stops the scroll, drives engagement,
    and builds authentic communities. You understand the nuances of each platform and
    always write in a human, authentic voice — never sounding robotic or generic.
    
    Follow these content principles:
    1. Hook first — the first line must stop the scroll
    2. Value-first — lead with value, not promotion  
    3. Platform-native — write for each platform's unique culture
    4. Authentic — sound human, relatable, real
    5. CTA always — end with a clear call to action
    """

    def __init__(self, provider: str = "auto"):
        self.provider = provider if provider != "auto" else self._detect_provider()
        self.client = self._init_client()

    def _detect_provider(self) -> str:
        """Auto-detect available AI provider from environment."""
        checks = [
            ("ANTHROPIC_API_KEY", "claude"),
            ("OPENAI_API_KEY", "openai"),
            ("GOOGLE_API_KEY", "gemini"),
            ("XAI_API_KEY", "grok"),
            ("OLLAMA_HOST", "ollama"),
        ]
        for env_var, provider in checks:
            if os.getenv(env_var):
                logger.info(f"Auto-detected AI provider: {provider}")
                return provider
        raise EnvironmentError(
            "No AI provider configured. Set one of: ANTHROPIC_API_KEY, OPENAI_API_KEY, "
            "GOOGLE_API_KEY, XAI_API_KEY, or OLLAMA_HOST"
        )

    def _init_client(self):
        """Initialize the AI client for the detected provider."""
        initializers = {
            "claude": self._init_claude,
            "openai": self._init_openai,
            "gemini": self._init_gemini,
            "grok": self._init_grok,
            "ollama": self._init_ollama,
        }
        fn = initializers.get(self.provider)
        if not fn:
            raise ValueError(f"Unknown provider: {self.provider}")
        return fn()

    def _init_claude(self):
        try:
            import anthropic
            return anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
        except ImportError:
            raise ImportError("Install anthropic: pip install anthropic")

    def _init_openai(self):
        try:
            from openai import OpenAI
            return OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        except ImportError:
            raise ImportError("Install openai: pip install openai")

    def _init_gemini(self):
        try:
            import google.generativeai as genai
            genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
            return genai.GenerativeModel(
                model_name="gemini-2.0-flash",
                system_instruction=self.SYSTEM_PROMPT,
            )
        except ImportError:
            raise ImportError("Install google-generativeai: pip install google-generativeai")

    def _init_grok(self):
        try:
            from openai import OpenAI
            return OpenAI(
                api_key=os.getenv("XAI_API_KEY"),
                base_url="https://api.x.ai/v1",
            )
        except ImportError:
            raise ImportError("Install openai: pip install openai")

    def _init_ollama(self):
        try:
            import ollama
            return ollama.Client(host=os.getenv("OLLAMA_HOST", "http://localhost:11434"))
        except ImportError:
            raise ImportError("Install ollama: pip install ollama")

    # ─── Core Generation ──────────────────────────────────────────────────────

    def generate(self, prompt: str, max_tokens: int = 4000) -> str:
        """Generate text using the configured AI provider."""
        generators = {
            "claude": self._generate_claude,
            "openai": self._generate_openai,
            "gemini": self._generate_gemini,
            "grok": self._generate_grok,
            "ollama": self._generate_ollama,
        }
        return generators[self.provider](prompt, max_tokens)

    def _generate_claude(self, prompt: str, max_tokens: int) -> str:
        message = self.client.messages.create(
            model=os.getenv("CLAUDE_MODEL", "claude-opus-4-5"),
            max_tokens=max_tokens,
            system=self.SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
        )
        return message.content[0].text

    def _generate_openai(self, prompt: str, max_tokens: int) -> str:
        response = self.client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o"),
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": self.SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )
        return response.choices[0].message.content

    def _generate_gemini(self, prompt: str, max_tokens: int) -> str:
        response = self.client.generate_content(prompt)
        return response.text

    def _generate_grok(self, prompt: str, max_tokens: int) -> str:
        response = self.client.chat.completions.create(
            model=os.getenv("GROK_MODEL", "grok-3"),
            max_tokens=max_tokens,
            messages=[
                {"role": "system", "content": self.SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )
        return response.choices[0].message.content

    def _generate_ollama(self, prompt: str, max_tokens: int) -> str:
        response = self.client.chat(
            model=os.getenv("OLLAMA_MODEL", "llama3.1"),
            messages=[
                {"role": "system", "content": self.SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
        )
        return response["message"]["content"]

    # ─── High-Level Content Generators ───────────────────────────────────────

    def generate_post_package(self, request: ContentRequest) -> Dict[str, Any]:
        """Generate a complete content package for all requested platforms."""
        platform_str = ", ".join(request.platforms)
        pillars_str = ", ".join(request.content_pillars or ["educate", "entertain", "inspire"])

        prompt = f"""
Create a complete social media content package with these requirements:

TOPIC: {request.topic}
NICHE: {request.niche or request.topic}
TARGET AUDIENCE: {request.audience}
PLATFORMS: {platform_str}
BRAND VOICE: {request.brand_voice}
CONTENT PILLARS: {pillars_str}
NUMBER OF POSTS: {request.num_posts}
LANGUAGE: {request.language}

For each post, provide:
1. Platform name
2. Post type (post/reel/carousel/thread/story)
3. HOOK (first line, scroll-stopping)
4. BODY (main content)
5. CTA (call to action)
6. HASHTAGS (platform-optimized, 8-15 for Instagram, 1-2 for X, etc.)
7. TAGLINE (memorable phrase)
8. For reels/videos: Script + B-roll notes + audio suggestion
9. Image prompt (for AI image generation)

Format as valid JSON matching this schema:
{{
  "content_package": {{
    "topic": "string",
    "posts": [
      {{
        "platform": "string",
        "type": "string", 
        "hook": "string",
        "body": "string",
        "cta": "string",
        "full_caption": "string",
        "hashtags": ["string"],
        "tagline": "string",
        "image_prompt": "string",
        "reel_script": "string or null",
        "b_roll_notes": "string or null",
        "audio_suggestion": "string or null"
      }}
    ]
  }}
}}
"""
        raw = self.generate(prompt)
        # Extract JSON from response
        return self._parse_json_response(raw)

    def generate_reel_script(self, topic: str, duration: int = 60, style: str = "educational") -> Dict:
        """Generate a detailed reel script."""
        prompt = f"""
Write a complete, production-ready Reel/TikTok/YouTube Shorts script:

TOPIC: {topic}
DURATION: {duration} seconds
STYLE: {style}

Include:
1. Opening hook (0-3 seconds) - MUST stop the scroll immediately
2. Setup (3-8 seconds) 
3. Main content broken into timed segments
4. Payoff/resolution
5. CTA (last 5 seconds)
6. Text overlay suggestions
7. B-roll shot list
8. Music/audio recommendation
9. Transitions between segments

Format as JSON with timing, visuals, voiceover, text_overlay, and b_roll fields.
"""
        raw = self.generate(prompt)
        return self._parse_json_response(raw)

    def generate_hashtag_set(self, topic: str, platform: str, niche: str = "") -> Dict:
        """Generate an optimized hashtag set for a platform."""
        prompt = f"""
Generate an optimized hashtag strategy for:
TOPIC: {topic}
PLATFORM: {platform}
NICHE: {niche or topic}

Provide:
- 3 mega hashtags (1M+ posts) 
- 5 mid-tier hashtags (100K-1M posts)
- 7 niche hashtags (<100K posts)
- 2 branded hashtag suggestions
- 1 trending hashtag to ride

Explain the posting strategy for {platform}.
Format as JSON.
"""
        raw = self.generate(prompt)
        return self._parse_json_response(raw)

    def generate_content_calendar(self, topic: str, duration_days: int = 30, 
                                   platforms: List[str] = None) -> Dict:
        """Generate a full content calendar."""
        platforms_str = ", ".join(platforms or ["instagram", "x", "tiktok", "linkedin"])
        prompt = f"""
Create a {duration_days}-day content calendar for:
TOPIC/BRAND: {topic}
PLATFORMS: {platforms_str}

For each day, specify:
- Date (Day 1, Day 2, etc.)
- Platform
- Content type
- Topic/angle
- Content pillar (educate/entertain/inspire/engage/promote)
- Brief hook idea

Balance: 70% value content, 30% promotional. 
Ensure variety in format and pillar.
Format as JSON array.
"""
        raw = self.generate(prompt)
        return self._parse_json_response(raw)

    def _parse_json_response(self, raw: str) -> Dict:
        """Extract and parse JSON from AI response."""
        # Try to find JSON in the response
        import re
        # Look for JSON block
        json_match = re.search(r'```json\s*(.*?)\s*```', raw, re.DOTALL)
        if json_match:
            raw = json_match.group(1)
        else:
            # Try to find raw JSON
            start = raw.find('{')
            end = raw.rfind('}') + 1
            if start >= 0 and end > start:
                raw = raw[start:end]

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            # Return as raw text if JSON parsing fails
            return {"raw_response": raw, "parse_error": True}


# ─── CLI Usage ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Generate social media content with AI")
    parser.add_argument("--topic", required=True, help="Content topic")
    parser.add_argument("--platforms", nargs="+", default=["instagram", "x", "tiktok"],
                        help="Target platforms")
    parser.add_argument("--voice", default="casual and engaging", help="Brand voice")
    parser.add_argument("--posts", type=int, default=5, help="Number of posts")
    parser.add_argument("--provider", default="auto", help="AI provider")
    parser.add_argument("--output", help="Output JSON file path")
    args = parser.parse_args()

    generator = AIContentGenerator(provider=args.provider)
    request = ContentRequest(
        topic=args.topic,
        platforms=args.platforms,
        brand_voice=args.voice,
        num_posts=args.posts,
    )

    result = generator.generate_post_package(request)

    if args.output:
        with open(args.output, "w") as f:
            json.dump(result, f, indent=2)
        print(f"Content saved to {args.output}")
    else:
        print(json.dumps(result, indent=2))
