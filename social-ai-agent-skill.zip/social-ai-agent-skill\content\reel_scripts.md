# Reel & Short-Form Video Script Templates

## 30-Second Reel Template (High Engagement)

```
=== REEL SCRIPT: [TOPIC] ===
Duration: 30 seconds
Style: [Educational/Entertainment/Inspirational]
Platform: Instagram Reels / TikTok / YouTube Shorts

---

[0:00–0:03] HOOK
Visual: [DESCRIBE OPENING SHOT]
Text Overlay: "[SCROLL-STOPPING STATEMENT IN CAPS]"
Audio: [TRENDING SOUND or UPBEAT MUSIC]
Action: Start mid-action, no intro

---

[0:03–0:08] SETUP  
Visual: [CUT TO NEXT SHOT]
Voiceover/Text: "[WHY THIS MATTERS TO VIEWER]"
Transition: [QUICK CUT / ZOOM IN / WHIP PAN]

---

[0:08–0:22] CONTENT (3 RAPID POINTS)
Point 1 [0:08–0:12]:
  Visual: [SHOT DESCRIPTION]
  Text: "[POINT 1 — SHORT]"
  
Point 2 [0:12–0:16]:  
  Visual: [SHOT DESCRIPTION]
  Text: "[POINT 2 — SHORT]"
  
Point 3 [0:16–0:22]:
  Visual: [SHOT DESCRIPTION]
  Text: "[POINT 3 — SHORT]"

---

[0:22–0:28] PAYOFF
Visual: [RESULT / TRANSFORMATION SHOT]
Text: "[PUNCHLINE or REVELATION]"

---

[0:28–0:30] CTA
Text Overlay: "FOLLOW FOR MORE 🔔" or "SAVE THIS 🔖"
Visual: [BRAND ELEMENT]
Audio: [FADE OUT]

=== END SCRIPT ===
```

---

## 60-Second Educational Reel Template

```
=== 60-SEC EDUCATIONAL REEL ===
Topic: [TOPIC]
Hook style: Question / Bold claim / Story
Target: [PLATFORM]

[0:00–0:03] HOOK
"[PROVOCATIVE QUESTION or BOLD STATEMENT]"
Text: "[SAME OR SUPPORTING LINE]"

[0:03–0:10] PROMISE
"In the next 60 seconds, I'll show you [SPECIFIC BENEFIT]"
Text: "Watch till the end for the [BONUS TIP]"

[0:10–0:15] POINT 1: [SUBHEADING]
"[EXPLANATION — 2-3 sentences max]"
Visual: [b-roll or graphic]

[0:15–0:25] POINT 2: [SUBHEADING]
"[EXPLANATION — 2-3 sentences max]"
Visual: [b-roll or graphic]

[0:25–0:35] POINT 3: [SUBHEADING]
"[EXPLANATION — 2-3 sentences max]"
Visual: [b-roll or graphic]

[0:35–0:45] BONUS POINT (The Payoff)
"But here's the part nobody talks about..."
"[SURPRISING INSIGHT]"

[0:45–0:55] CALL BACK
"Remember I said [CALLBACK TO HOOK]? That's because [EXPLANATION]"

[0:55–1:00] CTA
"If this helped you, [FOLLOW/SAVE/SHARE]"
"I post [CADENCE] on [TOPIC]"
Text: "FOLLOW → [HANDLE]"

=== END ===
```

---

## Trending Format Scripts

### POV Reel
```
TEXT ON SCREEN: "POV: You [RELATABLE SCENARIO]"
Duration: 15-30 seconds

[Scene plays out silently with text overlays]
Ending: Unexpected twist or emotional resolution

Caption: "anyone else? 👀"
```

### Get Ready With Me (GRWM)
```
[Start mid-action — getting ready/doing task]
Voiceover: "So today I want to talk about [TOPIC UNRELATED TO ACTION]"
[Continue getting ready while talking]
Value: Share insights, tips, or story WHILE doing mundane task
End: Finished getting ready + summary of main point
```

### Tutorial / How-To (Step-by-Step)
```
Hook: "Here's how to [RESULT] in [X] steps:"
Step 1: [Show on screen] "Step 1: [ACTION]"
Step 2: [Show on screen] "Step 2: [ACTION]"
Step 3: [Show on screen] "Step 3: [ACTION]"
Result: "[SHOW THE OUTCOME]"
CTA: "Full tutorial in bio / comments"
```

### Before & After
```
[0:00–0:03] "BEFORE:" visual — the problem/original state
[0:03–0:05] Sound effect / transition
[0:05–0:15] "AFTER:" visual — the transformation
[0:15–0:25] "Here's exactly what I changed:"
  - Change 1
  - Change 2
  - Change 3
[0:25–0:30] CTA
```

---

## B-Roll Shot List Template

```
=== B-ROLL SHOT LIST ===

ESTABLISHING SHOTS
□ Wide shot of [LOCATION/SCENE]
□ Close-up of [KEY PROP or PRODUCT]
□ Hands doing [RELEVANT ACTION]

PROCESS SHOTS  
□ Over-the-shoulder [TASK]
□ Time-lapse of [PROCESS]
□ Detail/macro of [KEY ELEMENT]

LIFESTYLE SHOTS
□ Subject smiling/reacting naturally
□ [ENVIRONMENT] with soft focus background
□ Product/result in natural setting

BRAND SHOTS
□ Logo/brand visible in scene
□ Brand colors in background
□ [SIGNATURE BRAND ELEMENT]
```

---

## Audio Strategy

### Trending Audio Tips
1. **Check "Browse" or "Trending Sounds"** on TikTok/Instagram weekly
2. **Use audio within 24–48 hours** of it trending — before competition peaks
3. **Audio + text overlay** = reach boost (audio for For You, text for silent viewers)
4. **Original audio** — creates your own trend-able sound

### Audio Types by Content
| Content Type | Audio Style |
|-------------|------------|
| Educational | Lo-fi, ambient, soft background |
| Entertainment | Trending sound, pop music |
| Motivational | Epic/cinematic, rising build |
| POV/Story | Trending dialogue audio |
| Product | Upbeat, positive, energetic |
| Aesthetic | Calm, indie, ambient |
