#!/usr/bin/env python3
"""
Social AI Agent Skill — Multi-Platform Publisher
Publishes content to all configured social media platforms.
"""

import os
import json
import time
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field
from datetime import datetime

from api_connector import SocialAPIConnector

logger = logging.getLogger(__name__)


@dataclass
class Post:
    post_id: str
    platform: str
    post_type: str  # post, reel, story, carousel, thread
    caption: str
    hashtags: List[str] = field(default_factory=list)
    media_urls: List[str] = field(default_factory=list)
    scheduled_time: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def full_caption(self) -> str:
        """Caption with hashtags appended."""
        tags = " ".join(self.hashtags)
        return f"{self.caption}\n\n{tags}".strip()


@dataclass
class PublishResult:
    post_id: str
    platform: str
    success: bool
    platform_post_id: Optional[str] = None
    post_url: Optional[str] = None
    published_at: Optional[str] = None
    error: Optional[str] = None
    retry_count: int = 0


class MultiPlatformPublisher:
    """
    Publishes content across all social media platforms with
    automatic retry logic, rate limit handling, and error recovery.
    """

    MAX_RETRIES = 3
    RETRY_DELAYS = [30, 60, 120]  # seconds

    def __init__(self):
        self.connector = SocialAPIConnector()
        self.results: List[PublishResult] = []

    # ─── Main Entry Points ───────────────────────────────────────────────────

    def publish(self, post: Post) -> PublishResult:
        """Publish a single post with retry logic."""
        for attempt in range(self.MAX_RETRIES):
            try:
                result = self._dispatch(post)
                result.retry_count = attempt
                self.results.append(result)
                if result.success:
                    logger.info(f"✅ Published to {post.platform}: {result.post_url}")
                return result
            except RateLimitError:
                delay = self.RETRY_DELAYS[min(attempt, len(self.RETRY_DELAYS) - 1)]
                logger.warning(f"Rate limited on {post.platform}. Retrying in {delay}s...")
                time.sleep(delay)
            except Exception as e:
                logger.error(f"Error publishing to {post.platform}: {e}")
                if attempt == self.MAX_RETRIES - 1:
                    result = PublishResult(
                        post_id=post.post_id,
                        platform=post.platform,
                        success=False,
                        error=str(e),
                        retry_count=attempt + 1,
                    )
                    self.results.append(result)
                    return result

    def publish_all(self, posts: List[Post]) -> List[PublishResult]:
        """Publish a list of posts, respecting platform rate limits."""
        results = []
        platform_last_post: Dict[str, float] = {}

        for post in posts:
            # Enforce minimum gap between posts on same platform
            last = platform_last_post.get(post.platform, 0)
            gap = self._min_gap(post.platform)
            wait = gap - (time.time() - last)
            if wait > 0:
                logger.info(f"Waiting {wait:.0f}s before next {post.platform} post...")
                time.sleep(wait)

            result = self.publish(post)
            results.append(result)
            platform_last_post[post.platform] = time.time()

        return results

    # ─── Platform Dispatchers ─────────────────────────────────────────────────

    def _dispatch(self, post: Post) -> PublishResult:
        """Route post to correct platform publisher."""
        dispatchers = {
            "facebook": self._publish_facebook,
            "instagram": self._publish_instagram,
            "x": self._publish_x,
            "twitter": self._publish_x,
            "tiktok": self._publish_tiktok,
            "linkedin": self._publish_linkedin,
            "youtube": self._publish_youtube,
            "threads": self._publish_threads,
        }
        fn = dispatchers.get(post.platform.lower())
        if not fn:
            raise ValueError(f"Unsupported platform: {post.platform}")
        return fn(post)

    def _publish_facebook(self, post: Post) -> PublishResult:
        """Publish to Facebook Page."""
        client = self.connector.get_client("meta")
        creds = self.connector.credentials["meta"]
        page_id = creds["page_id"]

        if post.media_urls and post.post_type == "video":
            response = client.post(
                f"{page_id}/videos",
                file_url=post.media_urls[0],
                description=post.full_caption,
                content_category="REELS" if post.post_type == "reel" else "OTHER",
            )
        elif post.media_urls:
            response = client.post(
                f"{page_id}/photos",
                url=post.media_urls[0],
                caption=post.full_caption,
            )
        else:
            response = client.post(f"{page_id}/feed", message=post.full_caption)

        post_id = response.get("id", "")
        return PublishResult(
            post_id=post.post_id,
            platform="facebook",
            success=True,
            platform_post_id=post_id,
            post_url=f"https://facebook.com/{post_id}",
            published_at=datetime.utcnow().isoformat(),
        )

    def _publish_instagram(self, post: Post) -> PublishResult:
        """Publish to Instagram via Graph API (2-step process)."""
        client = self.connector.get_client("meta")
        creds = self.connector.credentials["meta"]
        ig_id = creds["ig_account_id"]

        # Step 1: Create media container
        container_params = {"caption": post.full_caption}

        if post.post_type == "reel" and post.media_urls:
            container_params.update({"media_type": "REELS", "video_url": post.media_urls[0]})
        elif post.post_type == "carousel" and post.media_urls:
            # Create child containers
            children = []
            for url in post.media_urls:
                child = client.post(f"{ig_id}/media", image_url=url)
                children.append(child["id"])
            container_params.update({"media_type": "CAROUSEL_ALBUM", "children": ",".join(children)})
        elif post.media_urls:
            container_params.update({"image_url": post.media_urls[0]})

        container = client.post(f"{ig_id}/media", **container_params)
        container_id = container["id"]

        # Wait for video processing
        if post.post_type in ("reel", "video"):
            time.sleep(10)

        # Step 2: Publish container
        result = client.post(f"{ig_id}/media_publish", creation_id=container_id)
        ig_post_id = result.get("id", "")

        return PublishResult(
            post_id=post.post_id,
            platform="instagram",
            success=True,
            platform_post_id=ig_post_id,
            post_url=f"https://instagram.com/p/{ig_post_id}",
            published_at=datetime.utcnow().isoformat(),
        )

    def _publish_x(self, post: Post) -> PublishResult:
        """Publish to X (Twitter)."""
        client = self.connector.get_client("x")

        if post.post_type == "thread":
            return self._publish_x_thread(client, post)

        # Upload media if present
        media_ids = []
        if post.media_urls:
            import tweepy
            auth = tweepy.OAuth1UserHandler(
                self.connector.credentials["x"]["api_key"],
                self.connector.credentials["x"]["api_secret"],
                self.connector.credentials["x"]["access_token"],
                self.connector.credentials["x"]["access_secret"],
            )
            api_v1 = tweepy.API(auth)
            for url in post.media_urls[:4]:  # X allows max 4 images
                media = api_v1.media_upload(url)
                media_ids.append(media.media_id)

        tweet = client.create_tweet(
            text=post.full_caption[:280],
            media_ids=media_ids if media_ids else None,
        )
        tweet_id = tweet.data["id"]

        return PublishResult(
            post_id=post.post_id,
            platform="x",
            success=True,
            platform_post_id=tweet_id,
            post_url=f"https://x.com/i/web/status/{tweet_id}",
            published_at=datetime.utcnow().isoformat(),
        )

    def _publish_x_thread(self, client, post: Post) -> PublishResult:
        """Publish a Twitter/X thread."""
        tweets = post.metadata.get("thread_tweets", [post.caption])
        previous_id = None
        first_id = None

        for i, tweet_text in enumerate(tweets):
            params = {"text": tweet_text[:280]}
            if previous_id:
                params["reply"] = {"in_reply_to_tweet_id": previous_id}

            tweet = client.create_tweet(**params)
            tweet_id = tweet.data["id"]

            if i == 0:
                first_id = tweet_id
            previous_id = tweet_id
            time.sleep(2)  # Small delay between thread tweets

        return PublishResult(
            post_id=post.post_id,
            platform="x",
            success=True,
            platform_post_id=first_id,
            post_url=f"https://x.com/i/web/status/{first_id}",
            published_at=datetime.utcnow().isoformat(),
        )

    def _publish_tiktok(self, post: Post) -> PublishResult:
        """Publish a video to TikTok."""
        client = self.connector.get_client("tiktok")

        if not post.media_urls:
            raise ValueError("TikTok requires a video URL")

        result = client.post_video(
            video_url=post.media_urls[0],
            caption=post.full_caption[:2200],
            privacy=post.metadata.get("privacy", "PUBLIC_TO_EVERYONE"),
        )
        publish_id = result.get("data", {}).get("publish_id", "")

        return PublishResult(
            post_id=post.post_id,
            platform="tiktok",
            success=True,
            platform_post_id=publish_id,
            post_url="https://tiktok.com/@[your_handle]",
            published_at=datetime.utcnow().isoformat(),
        )

    def _publish_linkedin(self, post: Post) -> PublishResult:
        """Publish to LinkedIn."""
        client = self.connector.get_client("linkedin")
        result = client.create_post(text=post.full_caption[:3000])
        post_id = result.get("id", "")

        return PublishResult(
            post_id=post.post_id,
            platform="linkedin",
            success=True,
            platform_post_id=post_id,
            post_url=f"https://linkedin.com/feed/update/{post_id}",
            published_at=datetime.utcnow().isoformat(),
        )

    def _publish_youtube(self, post: Post) -> PublishResult:
        """Upload a video to YouTube."""
        client = self.connector.get_client("youtube")
        from googleapiclient.http import MediaFileUpload

        body = {
            "snippet": {
                "title": post.metadata.get("title", post.caption[:100]),
                "description": post.full_caption,
                "tags": [t.lstrip("#") for t in post.hashtags],
                "categoryId": post.metadata.get("category_id", "22"),
            },
            "status": {"privacyStatus": post.metadata.get("privacy", "public")},
        }

        if post.media_urls:
            # For URL-based upload, use requests to download first
            import requests, tempfile
            with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as f:
                r = requests.get(post.media_urls[0], stream=True)
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
                temp_path = f.name

            media = MediaFileUpload(temp_path, mimetype="video/mp4", resumable=True)
            response = client.videos().insert(part="snippet,status", body=body, media_body=media).execute()
            video_id = response.get("id", "")
        else:
            raise ValueError("YouTube requires a video file")

        return PublishResult(
            post_id=post.post_id,
            platform="youtube",
            success=True,
            platform_post_id=video_id,
            post_url=f"https://youtube.com/watch?v={video_id}",
            published_at=datetime.utcnow().isoformat(),
        )

    def _publish_threads(self, post: Post) -> PublishResult:
        """Publish to Threads (Meta's platform via Graph API)."""
        # Threads uses Meta Graph API similar to Instagram
        client = self.connector.get_client("meta")
        ig_id = self.connector.credentials["meta"]["ig_account_id"]

        container = client.post(f"{ig_id}/threads", text=post.full_caption[:500])
        container_id = container["id"]

        result = client.post(f"{ig_id}/threads_publish", creation_id=container_id)
        thread_id = result.get("id", "")

        return PublishResult(
            post_id=post.post_id,
            platform="threads",
            success=True,
            platform_post_id=thread_id,
            post_url=f"https://threads.net/t/{thread_id}",
            published_at=datetime.utcnow().isoformat(),
        )

    # ─── Helpers ──────────────────────────────────────────────────────────────

    def _min_gap(self, platform: str) -> int:
        """Minimum seconds between posts on the same platform."""
        return {"tiktok": 300, "instagram": 120, "x": 60, "facebook": 120, "linkedin": 180}.get(
            platform.lower(), 60
        )

    def get_summary(self) -> Dict[str, Any]:
        """Return a summary of all publish results."""
        total = len(self.results)
        successful = sum(1 for r in self.results if r.success)
        return {
            "total_attempted": total,
            "successful": successful,
            "failed": total - successful,
            "results": [
                {
                    "post_id": r.post_id,
                    "platform": r.platform,
                    "success": r.success,
                    "url": r.post_url,
                    "error": r.error,
                }
                for r in self.results
            ],
        }


class RateLimitError(Exception):
    pass


# ─── CLI Usage ────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Publish content to social platforms")
    parser.add_argument("--input", required=True, help="JSON file with posts to publish")
    parser.add_argument("--platform", help="Publish only to this platform")
    args = parser.parse_args()

    with open(args.input) as f:
        data = json.load(f)

    posts = [Post(**p) for p in data["posts"]]

    if args.platform:
        posts = [p for p in posts if p.platform == args.platform]

    publisher = MultiPlatformPublisher()
    publisher.publish_all(posts)

    summary = publisher.get_summary()
    print(json.dumps(summary, indent=2))
