#!/usr/bin/env python3
"""
Social AI Agent Skill — Unified Social API Connector
Supports: Meta (Facebook, Instagram), X (Twitter), TikTok, LinkedIn, YouTube
"""

import os
import json
import time
import logging
from typing import Optional, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)


@dataclass
class PlatformCredentials:
    platform: str
    credentials: Dict[str, str]


class SocialAPIConnector:
    """
    Universal connector for all major social media platform APIs.
    Credentials loaded from environment variables or configs/platforms.yaml
    """

    def __init__(self, config_path: str = "configs/platforms.yaml"):
        self.config_path = config_path
        self.credentials = self._load_credentials()
        self.session_tokens: Dict[str, str] = {}

    def _load_credentials(self) -> Dict[str, Dict[str, str]]:
        """Load credentials from environment variables (preferred) or config file."""
        return {
            "meta": {
                "app_id": os.getenv("META_APP_ID", ""),
                "app_secret": os.getenv("META_APP_SECRET", ""),
                "access_token": os.getenv("META_ACCESS_TOKEN", ""),
                "page_id": os.getenv("META_PAGE_ID", ""),
                "ig_account_id": os.getenv("META_IG_ACCOUNT_ID", ""),
            },
            "x": {
                "api_key": os.getenv("X_API_KEY", ""),
                "api_secret": os.getenv("X_API_SECRET", ""),
                "access_token": os.getenv("X_ACCESS_TOKEN", ""),
                "access_secret": os.getenv("X_ACCESS_SECRET", ""),
                "bearer_token": os.getenv("X_BEARER_TOKEN", ""),
            },
            "tiktok": {
                "client_key": os.getenv("TIKTOK_CLIENT_KEY", ""),
                "client_secret": os.getenv("TIKTOK_CLIENT_SECRET", ""),
                "access_token": os.getenv("TIKTOK_ACCESS_TOKEN", ""),
            },
            "linkedin": {
                "client_id": os.getenv("LINKEDIN_CLIENT_ID", ""),
                "client_secret": os.getenv("LINKEDIN_CLIENT_SECRET", ""),
                "access_token": os.getenv("LINKEDIN_ACCESS_TOKEN", ""),
                "person_urn": os.getenv("LINKEDIN_PERSON_URN", ""),
            },
            "youtube": {
                "api_key": os.getenv("YOUTUBE_API_KEY", ""),
                "channel_id": os.getenv("YOUTUBE_CHANNEL_ID", ""),
                "oauth_credentials": os.getenv("YOUTUBE_OAUTH_CREDENTIALS", ""),
            },
        }

    def validate_credentials(self, platform: str) -> bool:
        """Check if all required credentials are configured for a platform."""
        creds = self.credentials.get(platform, {})
        missing = [k for k, v in creds.items() if not v]
        if missing:
            logger.error(f"Missing credentials for {platform}: {missing}")
            return False
        return True

    def get_client(self, platform: str):
        """Factory method — returns the appropriate platform client."""
        clients = {
            "meta": self._get_meta_client,
            "instagram": self._get_meta_client,
            "facebook": self._get_meta_client,
            "x": self._get_x_client,
            "twitter": self._get_x_client,
            "tiktok": self._get_tiktok_client,
            "linkedin": self._get_linkedin_client,
            "youtube": self._get_youtube_client,
        }
        factory = clients.get(platform.lower())
        if not factory:
            raise ValueError(f"Unsupported platform: {platform}")
        return factory()

    def _get_meta_client(self):
        """Returns a Meta Graph API client."""
        try:
            import facebook  # facebook-sdk
            creds = self.credentials["meta"]
            graph = facebook.GraphAPI(access_token=creds["access_token"], version="19.0")
            return graph
        except ImportError:
            logger.warning("facebook-sdk not installed. Using requests fallback.")
            return self._meta_requests_client()

    def _meta_requests_client(self):
        """Lightweight fallback using requests."""
        import requests
        creds = self.credentials["meta"]

        class MetaClient:
            BASE = "https://graph.facebook.com/v19.0"
            token = creds["access_token"]

            def post(self, endpoint, **data):
                data["access_token"] = self.token
                r = requests.post(f"{self.BASE}/{endpoint}", data=data)
                r.raise_for_status()
                return r.json()

            def get(self, endpoint, **params):
                params["access_token"] = self.token
                r = requests.get(f"{self.BASE}/{endpoint}", params=params)
                r.raise_for_status()
                return r.json()

        return MetaClient()

    def _get_x_client(self):
        """Returns a Tweepy (X API v2) client."""
        try:
            import tweepy
            creds = self.credentials["x"]
            client = tweepy.Client(
                bearer_token=creds["bearer_token"],
                consumer_key=creds["api_key"],
                consumer_secret=creds["api_secret"],
                access_token=creds["access_token"],
                access_token_secret=creds["access_secret"],
                wait_on_rate_limit=True,
            )
            return client
        except ImportError:
            raise ImportError("Install tweepy: pip install tweepy")

    def _get_tiktok_client(self):
        """Returns a TikTok API client (via requests)."""
        import requests
        creds = self.credentials["tiktok"]

        class TikTokClient:
            BASE = "https://open.tiktokapis.com/v2"
            token = creds["access_token"]

            def post_video(self, video_url, caption, privacy="PUBLIC_TO_EVERYONE"):
                headers = {"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"}
                payload = {
                    "post_info": {
                        "title": caption[:150],
                        "privacy_level": privacy,
                        "disable_duet": False,
                        "disable_comment": False,
                        "disable_stitch": False,
                    },
                    "source_info": {"source": "PULL_FROM_URL", "video_url": video_url},
                }
                r = requests.post(f"{self.BASE}/post/publish/video/init/", headers=headers, json=payload)
                r.raise_for_status()
                return r.json()

        return TikTokClient()

    def _get_linkedin_client(self):
        """Returns a LinkedIn API client."""
        import requests
        creds = self.credentials["linkedin"]

        class LinkedInClient:
            BASE = "https://api.linkedin.com/v2"
            token = creds["access_token"]
            person_urn = creds["person_urn"]

            def create_post(self, text, media_urn=None):
                headers = {
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json",
                    "X-Restli-Protocol-Version": "2.0.0",
                }
                payload = {
                    "author": f"urn:li:person:{self.person_urn}",
                    "lifecycleState": "PUBLISHED",
                    "specificContent": {
                        "com.linkedin.ugc.ShareContent": {
                            "shareCommentary": {"text": text},
                            "shareMediaCategory": "IMAGE" if media_urn else "NONE",
                        }
                    },
                    "visibility": {"com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC"},
                }
                if media_urn:
                    payload["specificContent"]["com.linkedin.ugc.ShareContent"]["media"] = [
                        {"status": "READY", "media": media_urn}
                    ]
                r = requests.post(f"{self.BASE}/ugcPosts", headers=headers, json=payload)
                r.raise_for_status()
                return r.json()

        return LinkedInClient()

    def _get_youtube_client(self):
        """Returns a YouTube Data API v3 client."""
        try:
            from googleapiclient.discovery import build
            from google.oauth2.credentials import Credentials
            import json
            creds_json = json.loads(self.credentials["youtube"]["oauth_credentials"])
            credentials = Credentials.from_authorized_user_info(creds_json)
            youtube = build("youtube", "v3", credentials=credentials)
            return youtube
        except ImportError:
            raise ImportError("Install google-api-python-client: pip install google-api-python-client")

    def test_connection(self, platform: str) -> Dict[str, Any]:
        """Test API connectivity for a platform."""
        if not self.validate_credentials(platform):
            return {"platform": platform, "connected": False, "error": "Missing credentials"}
        try:
            client = self.get_client(platform)
            return {"platform": platform, "connected": True, "client": type(client).__name__}
        except Exception as e:
            return {"platform": platform, "connected": False, "error": str(e)}


if __name__ == "__main__":
    # Test all connections
    connector = SocialAPIConnector()
    for platform in ["meta", "x", "tiktok", "linkedin", "youtube"]:
        result = connector.test_connection(platform)
        status = "✅" if result["connected"] else "❌"
        print(f"{status} {platform.upper()}: {result.get('error', 'Connected')}")
