# X (Twitter) Platform Guide

## Overview
X (formerly Twitter) is a real-time conversation platform built on brevity, wit, and speed. The algorithm rewards engagement velocity — posts that get quick engagement are pushed to Explore and For You pages.

---

## Algorithm Signals (Priority Order)
1. **Replies** — especially with engagement chains
2. **Retweets/Reposts** — with or without quote
3. **Likes** — simple but still counts
4. **Link clicks** — but X deprioritizes external links
5. **Bookmarks** — growing as a signal
6. **Watch time** (for video) — key since 2024

> **Important**: X actively **demotes** posts with external links in the first tweet. Put links in a reply to your own tweet, or in the thread's last tweet.

---

## Content Types & Specs

| Type | Limit | Best Use |
|------|-------|---------|
| Tweet | 280 chars (25k for Premium) | Hot takes, quick value |
| Thread | Unlimited tweets | Deep dives, storytelling |
| Quote Tweet | With/without commentary | Reactions, amplification |
| Reply | 280 chars | Community building |
| Poll | 2-4 options, 1-7 days | Engagement, research |
| Space (Audio) | Live, up to 11 speakers | Thought leadership |
| Video | MP4, max 512MB, 2min 20s | Demos, recaps |
| GIF | Max 15MB | Reactions, humor |
| Image | JPEG/PNG/WEBP, up to 4 images | Visual proof |

---

## X (Twitter) API v2

### Authentication
```python
import tweepy

# OAuth 1.0a (for user actions)
auth = tweepy.OAuth1UserHandler(
    consumer_key=X_API_KEY,
    consumer_secret=X_API_SECRET,
    access_token=X_ACCESS_TOKEN,
    access_token_secret=X_ACCESS_SECRET,
)
api = tweepy.API(auth)

# OAuth 2.0 (for read operations + v2 endpoints)
client = tweepy.Client(
    bearer_token=X_BEARER_TOKEN,
    consumer_key=X_API_KEY,
    consumer_secret=X_API_SECRET,
    access_token=X_ACCESS_TOKEN,
    access_token_secret=X_ACCESS_SECRET,
)
```

### Post a Tweet
```python
# Simple tweet
response = client.create_tweet(text="Your tweet content here!")

# Tweet with media
media = api.media_upload(filename="image.jpg")
response = client.create_tweet(
    text="Tweet with image!",
    media_ids=[media.media_id]
)

# Reply (thread continuation)
response = client.create_tweet(
    text="Thread continuation...",
    reply={"in_reply_to_tweet_id": previous_tweet_id}
)

# Poll
response = client.create_tweet(
    text="Quick poll question:",
    poll_options=["Option A", "Option B", "Option C"],
    poll_duration_minutes=1440  # 24 hours
)
```

### Post a Full Thread
```python
def post_thread(tweets: list[str]) -> str:
    """Post a Twitter thread. Returns URL of first tweet."""
    previous_id = None
    first_id = None
    
    for i, tweet_text in enumerate(tweets):
        params = {"text": tweet_text[:280]}
        if previous_id:
            params["reply"] = {"in_reply_to_tweet_id": previous_id}
        
        response = client.create_tweet(**params)
        tweet_id = response.data["id"]
        
        if i == 0:
            first_id = tweet_id
        previous_id = tweet_id
        
        time.sleep(2)  # Avoid rate limit
    
    return f"https://x.com/i/web/status/{first_id}"
```

---

## X Content Strategy

### The Thread Formula (Highest Engagement Format)
```
Tweet 1: [BOLD HOOK] — make a claim or promise
Tweet 2: [WHY IT MATTERS] — establish stakes
Tweet 3-7: [THE MEAT] — one insight per tweet, numbered
Tweet 8: [THE PLOT TWIST or SUMMARY]
Tweet 9: [NEXT STEPS or RESOURCES]  
Tweet 10: [CTA] — follow + bookmark + share

TIPS:
- Number your tweets: "3/10"
- Keep each tweet self-contained but curious-gap to next
- Use line breaks for readability
- Add images every 3-4 tweets for more impressions
```

### Best Content Types for X
1. **Threads** — educational deep dives
2. **Hot takes** — polarizing but respectful opinions
3. **Quote tweets** — react to news/trends
4. **Polls** — drives engagement and research
5. **Behind-the-scenes** — builds personal brand
6. **Data/stats** — screenshots of interesting data
7. **Memes** — platform-native humor

### Hashtag Rules for X
- **Maximum 2 hashtags** (more = algorithm penalty)
- Use **trending hashtags** when genuinely relevant
- For promotions: 1 branded hashtag is enough
- Best: **weave keywords inline** rather than hashtag-stuffing

### Rate Limits (X API v2 Free Tier)
| Action | Limit |
|--------|-------|
| Tweet creation | 300/3 hours |
| Read tweets | 500K/month |
| App logins | 50/day |

### Premium / Enterprise
- Higher tweet limits
- Full archive search
- Access to ad analytics
- Longer videos, audio Spaces recording
