# Example: Brand Launch Campaign

## Scenario
You're launching a new **DTC wellness brand** called "MindBloom" — an app for guided meditation and sleep improvement. Target: millennials (25–40), stressed professionals.

---

## Prompt to Social AI Agent Skill

```
Skill: social-ai-agent-skill

Task: Run a full launch campaign for MindBloom

Brand details:
- Product: Mindfulness + sleep app
- Tagline: "Find your calm in 10 minutes"
- USP: AI-personalized meditation sessions
- Price: Free trial, then $12.99/month
- Target: Stressed professionals, 25-40

Campaign goal: 10,000 app downloads in 30 days
Platforms: Instagram, TikTok, X, LinkedIn
Brand voice: Warm, calm, science-backed, slightly witty

Run all agents and produce a complete campaign package.
```

---

## Expected Agent Output

### Research Agent Output
```json
{
  "trends": [
    {"topic": "sleep anxiety", "platform": "tiktok", "heat_score": 9},
    {"topic": "10-minute meditation", "platform": "instagram", "heat_score": 8},
    {"topic": "work-life balance 2025", "platform": "linkedin", "heat_score": 7}
  ],
  "competitor_gaps": [
    "Headspace: Too formal, not relatable",
    "Calm: Premium feels distant",
    "Opportunity: Science + humor + authenticity"
  ],
  "top_hashtags": {
    "instagram": ["#mentalhealth", "#mindfulness", "#selfcare", "#meditation", "#sleepbetter"]
  }
}
```

### Content Agent — Sample Posts

**Instagram Feed Post:**
```
Hook: You've been lying in bed staring at the ceiling for 47 minutes.

You're not broken. You're just wired.

Here's what your brain actually needs to wind down at night:

→ Less screen doom-scrolling (yes, this post counts 😂)
→ 10 minutes of guided breathing
→ A consistent wind-down cue

We built MindBloom so your phone becomes the solution, not the problem.

✨ 7-day free trial. No credit card. Just calm.

Does this hit too close to home? Drop a 🙋 if you can relate.

[Link in bio]
```

**TikTok Reel Script:**
```
[0:00-0:03] HOOK
Text on screen: "POV: It's 2am and your brain won't stop"
Audio: Trending lo-fi sound

[0:03-0:12] RELATABLE CONTENT  
Show: Phone in dark room, screen bright
Text: "Sunday Scaries hitting different this week"

[0:12-0:30] SOLUTION REVEAL
Show: App opening, calming interface
Text: "10 minutes. That's all it takes with MindBloom"
Voiceover: "I went from 2 hours to fall asleep to under 20 minutes..."

[0:30-0:45] SOCIAL PROOF
Text: "42,000 people are sleeping better this month"

[0:45-0:55] CTA
Text: "Free trial in bio 🌙 No credit card needed"
Sound: Soft chime
```

**LinkedIn Post:**
```
Hook: Productivity tip nobody tells you: Sleep more strategically, not longer.

I spent 3 years optimizing my morning routine.
The real needle-mover? My evening routine.

Here's what changed my sleep (and my focus):

1. Phone out of bedroom by 9pm
2. 10 minutes of guided breathing (not "meditation" — just breathing)
3. Same wind-down time every night

My cognitive performance tests improved 23% in 6 weeks. No supplements. No fancy tech. Just habit design.

What's your pre-sleep routine? Drop it below — I'll feature the best ones.

#productivity #leadership #wellbeing #performance
```

### Schedule Agent Output
```
Day 1 (Launch Day):
  10:00 — Instagram: Brand introduction post  
  12:00 — X: Announcement thread (10 tweets)
  14:00 — LinkedIn: Founder story post
  18:00 — TikTok: Viral relatable reel

Day 2:
  09:00 — Instagram Stories: Poll "How long does it take you to fall asleep?"
  11:00 — Instagram: Educational carousel "5 sleep myths debunked"
  19:00 — TikTok: POV reel

[... continues for 30 days ...]
```

---

## Campaign Metrics Targets

| Metric | 30-Day Goal |
|--------|------------|
| Instagram Followers | +5,000 |
| TikTok Views | 500,000+ |
| App Downloads | 10,000 |
| Email List | 2,500 |
| Engagement Rate | 5%+ |
